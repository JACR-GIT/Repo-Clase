package Ejercicio_2;

import Ejercicio_1.Reproducible;

public class Calculadora implements OperacionesMatematicas{

    final static double Numero_Pi = Numero_Pi_Intefaz;

    public void suma(int a, int b) {
        double suma = a + b;
    }
    public void resta(int a, int b) {
        double resta = a - b;
    }
}
