package Ejercicio_17;

public interface Operacion {
    double ejecutar(int a, int b);
}
