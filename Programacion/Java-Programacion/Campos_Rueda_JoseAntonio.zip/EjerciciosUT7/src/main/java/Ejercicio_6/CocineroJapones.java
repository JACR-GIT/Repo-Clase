package Ejercicio_6;

public class CocineroJapones extends Cocinero{

    public void prepararIngredientes(){
        System.out.println("Cortando pescado");
    };

    public void cocinarPlato(){
        System.out.println("Preparando sushi");
    };
}
