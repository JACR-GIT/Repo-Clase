package Ejercicio_4;

public class Bicicleta implements Vehiculo {

    public void detener() {}

    public void mover() {
        System.out.println("Moviendo bicicleta");
    }
}
