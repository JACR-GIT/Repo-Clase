package Julian_30.Ejer_6;

public class Main {
    public static void main(String[] args) {
        Pianista pianista = new Pianista();
        pianista.crearObra();
        pianista.tocarInstrumento();
    }
}
