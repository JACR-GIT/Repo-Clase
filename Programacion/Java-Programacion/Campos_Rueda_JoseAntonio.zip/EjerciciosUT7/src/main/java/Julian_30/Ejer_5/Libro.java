package Julian_30.Ejer_5;

public class Libro extends Producto {
    public Libro(int id) {
        super(id);
    }
    public double calcularPrecio() {
        return 10;
    }
}
