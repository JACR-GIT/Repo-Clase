package Julian_30.Ejer_4;

public class Moto extends VehiculoMotorizado{
    public void acelerar() {
        arrancarMotor();
        System.out.println("Acelerando moto");
    }
}
