package Julian_30.Ejer_25;

public class Main {
    public static void main(String[] args) {
        Herramienta martillo = Herramienta.crearHerramienta("martillo");
        martillo.usar();
    }
}
