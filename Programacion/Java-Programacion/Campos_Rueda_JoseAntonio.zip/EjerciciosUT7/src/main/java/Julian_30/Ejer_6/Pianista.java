package Julian_30.Ejer_6;

public class Pianista extends Musico {
    public void crearObra() { System.out.println("Componiendo una pieza"); }
    public void tocarInstrumento() { System.out.println("Tocando el piano"); }
}

