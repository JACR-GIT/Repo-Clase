package Julian_30.Ejer_4;

public abstract class VehiculoMotorizado {
    protected void arrancarMotor() {
        System.out.println("Arrancando motor");
    }
    public abstract void acelerar();
}
