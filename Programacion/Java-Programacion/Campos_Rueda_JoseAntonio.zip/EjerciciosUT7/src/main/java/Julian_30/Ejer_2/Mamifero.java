package Julian_30.Ejer_2;

public interface Mamifero extends Animal {
    void amamantar();
}
