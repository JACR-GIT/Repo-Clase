package Julian_30.Ejer_25;


public class Martillo extends Herramienta {
    public void usar() { System.out.println("Martillo golpeando"); }
}

