package Julian_30.Ejer_6;

public abstract class Musico extends Artista {
    public abstract void tocarInstrumento();
}