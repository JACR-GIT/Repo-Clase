package Julian_30.Ejer_6;

public abstract class Artista {
    public abstract void crearObra();
}
