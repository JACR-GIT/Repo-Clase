package Julian_30.Ejer_3;

public class Telefono implements DispositivoElectrinico{
    public void encender() {
        System.out.println("El telefono se enciende");
    }
    public void apagar() {
        System.out.println("El telefono se apaga");
    }
    public void reiniciar() {
        System.out.println("El telefono se reinicia");
    }
}
