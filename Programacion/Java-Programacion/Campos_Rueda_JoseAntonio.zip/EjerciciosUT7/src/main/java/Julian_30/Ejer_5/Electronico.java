package Julian_30.Ejer_5;

public class Electronico extends Producto{
    public Electronico(int id) {
        super(id);
    }
    public double calcularPrecio() {
        return 20;
    }
}
