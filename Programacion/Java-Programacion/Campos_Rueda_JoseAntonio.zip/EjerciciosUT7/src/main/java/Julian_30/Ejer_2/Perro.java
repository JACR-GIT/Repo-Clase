package Julian_30.Ejer_2;

public class Perro implements Mamifero{
    public void mover() {
        System.out.println("El perro se mueve");
    }

    public void amamantar() {
        System.out.println("El perro amamanta");
    }
}
