package Julian_30.Ejer_21;

public class Texto {
    public int contarLetras(String cadena) { return cadena.length(); }
}

