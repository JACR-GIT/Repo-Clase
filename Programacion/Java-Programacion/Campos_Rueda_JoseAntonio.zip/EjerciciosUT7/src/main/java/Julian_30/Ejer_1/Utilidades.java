package Julian_30.Ejer_1;

public interface Utilidades {
    static boolean esPar(int num){
        return num % 2 == 0;
    }
}
