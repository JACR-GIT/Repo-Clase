package Julian_30.Ejer_3;

public interface DispositivoElectrinico {
    void encender();
    void apagar();
    void reiniciar();
}
