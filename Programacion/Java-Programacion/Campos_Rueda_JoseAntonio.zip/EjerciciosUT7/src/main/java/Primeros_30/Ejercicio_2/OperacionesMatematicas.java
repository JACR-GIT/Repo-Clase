package Primeros_30.Ejercicio_2;

public interface OperacionesMatematicas {
    public void suma(int a, int b);
    public void resta(int a, int b);
    final static double Numero_Pi_Intefaz = 3.1416;
}
