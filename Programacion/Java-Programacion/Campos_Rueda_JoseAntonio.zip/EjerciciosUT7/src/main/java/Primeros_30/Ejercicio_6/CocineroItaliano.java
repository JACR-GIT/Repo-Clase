package Ejercicio_6;

public class CocineroItaliano extends Cocinero{

    public void prepararIngredientes(){
        System.out.println("Preparando pasta");
    };

    public void cocinarPlato(){
        System.out.println("Cocinado a fuego lento");
    };
}
