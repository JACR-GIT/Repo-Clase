package Ejercicio_10;

public class Main {
    public static void main(String[] args) {
        Televisor tv = new Televisor("Samsung", 150);

        tv.mostrarInfo();
    }
}