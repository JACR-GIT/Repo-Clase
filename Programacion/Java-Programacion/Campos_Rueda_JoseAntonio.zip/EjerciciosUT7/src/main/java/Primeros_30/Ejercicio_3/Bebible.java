package Ejercicio_3;

public interface Bebible {
    public void beber();
}
