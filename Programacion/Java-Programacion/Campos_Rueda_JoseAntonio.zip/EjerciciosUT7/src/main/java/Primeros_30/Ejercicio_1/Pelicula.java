package Ejercicio_1;

public class Pelicula implements Reproducible {
    public void reproducir() {
        System.out.println("Reproduciendo película");
    }
}
