package Ejercicio_3;

public interface Comestible {
    public void comer();
}
