package Ejercicio_19;

public class Calculadora {
    public static int cuadrado(int a) {
        return a * a;
    }


}
