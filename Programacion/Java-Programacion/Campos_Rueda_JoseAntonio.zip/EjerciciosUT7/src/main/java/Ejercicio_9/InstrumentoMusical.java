package Ejercicio_9;

public abstract class InstrumentoMusical {
    public void tocar(){
        System.out.println("Tocando instrumento musical");
    }
}
