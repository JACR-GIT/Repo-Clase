package Ejercicio_9;

public class Guitarra extends InstrumentoMusical{
    public void tocar(){
        System.out.println("Tocando guitarra");
    }
}
