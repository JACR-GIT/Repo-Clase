package Ejercicio_7;

public abstract class Figura {

    abstract double calcularArea();

    public String mostrarInfo(){
        return "Soy una figura";
    }
}
