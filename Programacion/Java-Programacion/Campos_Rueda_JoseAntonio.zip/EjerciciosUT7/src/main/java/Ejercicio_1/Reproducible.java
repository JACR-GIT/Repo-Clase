package Ejercicio_1;

public interface Reproducible {
    public void reproducir();
}
