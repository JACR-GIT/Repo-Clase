package modelos;

public enum Sexo {
    masculino, femenino, otro
}
