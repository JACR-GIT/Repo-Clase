package modelos;

public enum TipoVia {
    CALLE, AVENIDA, PLAZA, PLAZOLETA, CALLEJON, PASEO, BULEVAR
}
