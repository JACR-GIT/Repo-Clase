package org.example;

import com.aseguradora.utils.Marca;

public class Main {
    public static void main(String[] args) {
    }
}